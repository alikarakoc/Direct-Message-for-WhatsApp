# WpHelpers

### Direct Message for WhatsApp

- Send Direct Messages in WhatsApp without having the number in the contacts!
- Send a WhatsApp™ chat without adding a contact. Keep it fast, secret and clean. 
- Type a number, the message, press the send button and start a WhatsApp™ chat without saving a new contact. 

### WhatsApp İle Direkt Mesaj

- Numarayı rehberinize kayıt etmeden WhatsApp ile direkt olarak mesaj gönderebilirsiniz.
- Kişiyi rehberinize eklemeden, hızl ve temiz bir şekilde mesaj gönderebilirsiniz. 
- Bir numara yazın ve gönder düğmesine basın rehbere kayıt etmeden mesaj gönderin.

